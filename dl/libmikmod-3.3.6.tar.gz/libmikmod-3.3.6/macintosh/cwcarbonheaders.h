
	/* platform */
#define TARGET_API_MAC_OS8    0
#define TARGET_API_MAC_CARBON 1

#define MSL_USE_PRECOMPILED_HEADERS	0

#include "cwmikmodheaders.h"

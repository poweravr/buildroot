#include <stdio.h>
#include <sys/types.h>
#include <jpeglib.h>

int main ()
{
	void *p = &jpeg_CreateCompress;
	return 0;
}
